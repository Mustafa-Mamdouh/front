"use strict";
var IAttribute = (function () {
    function IAttribute() {
    }
    return IAttribute;
}());
exports.IAttribute = IAttribute;
//# sourceMappingURL=IAttribute.js.map