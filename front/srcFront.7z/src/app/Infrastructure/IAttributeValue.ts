export class IAttributeValue {
    value: string;
}