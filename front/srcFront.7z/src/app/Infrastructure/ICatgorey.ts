
export class ICategory {
    id: number;
    name: string;
    type: string;
}