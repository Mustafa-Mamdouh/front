"use strict";
var IComponent = (function () {
    function IComponent() {
    }
    return IComponent;
}());
exports.IComponent = IComponent;
//# sourceMappingURL=IComponent.js.map