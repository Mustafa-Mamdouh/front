"use strict";
var IService = (function () {
    function IService() {
    }
    return IService;
}());
exports.IService = IService;
//# sourceMappingURL=IService.js.map