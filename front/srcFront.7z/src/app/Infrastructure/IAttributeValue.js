"use strict";
var IAttributeValue = (function () {
    function IAttributeValue() {
    }
    return IAttributeValue;
}());
exports.IAttributeValue = IAttributeValue;
//# sourceMappingURL=IAttributeValue.js.map