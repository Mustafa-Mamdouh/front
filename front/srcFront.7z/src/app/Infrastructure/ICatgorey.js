"use strict";
var ICategory = (function () {
    function ICategory() {
    }
    return ICategory;
}());
exports.ICategory = ICategory;
//# sourceMappingURL=ICatgorey.js.map