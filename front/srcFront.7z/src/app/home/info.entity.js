"use strict";
var Info = (function () {
    function Info() {
    }
    return Info;
}());
exports.Info = Info;
//# sourceMappingURL=info.entity.js.map