export class Info {
    totalOrder: number;
    totalServices: number;
    totalComponent: number;
    totalCategory: number;
}