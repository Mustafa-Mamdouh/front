"use strict";
var OrderDto = (function () {
    function OrderDto() {
    }
    return OrderDto;
}());
exports.OrderDto = OrderDto;
//# sourceMappingURL=orderdto.entity.js.map