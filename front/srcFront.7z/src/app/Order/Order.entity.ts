export class Order
{
    address:string;
    email:string;
    phone:string;
    userName:string;
    quantity:number;
}