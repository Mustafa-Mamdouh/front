"use strict";
var Order = (function () {
    function Order() {
    }
    return Order;
}());
exports.Order = Order;
//# sourceMappingURL=Order.entity.js.map