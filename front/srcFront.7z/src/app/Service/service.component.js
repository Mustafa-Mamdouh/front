"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var service_service_1 = require("./service.service");
var IService_1 = require("../Infrastructure/IService");
var IComponent_1 = require("../Infrastructure/IComponent");
var IAttributeValue_1 = require("../Infrastructure/IAttributeValue");
var IAttribute_1 = require("../Infrastructure/IAttribute");
var category_service_1 = require("../category/category.service");
var component_service_1 = require("../Component/component.service");
var ServiceComponent = (function () {
    function ServiceComponent(serviceService, componentService, catgoreyService, changeDetectorRef, router) {
        this.serviceService = serviceService;
        this.componentService = componentService;
        this.catgoreyService = catgoreyService;
        this.changeDetectorRef = changeDetectorRef;
        this.router = router;
        this.toBeSaved = new IService_1.IService();
        this.candycomp = new IComponent_1.IComponent();
        this.serviceComponetList = new Array();
        this.attributeEdit = new IAttribute_1.IAttribute();
        this.attributeValueEdit = new Array();
        this.serviceAttributes = new Array();
        this.serviceAttributeValues = new Array();
        this.services = new Array();
    }
    ServiceComponent.prototype.getServices = function () {
        var _this = this;
        this.serviceService.getAllServices().subscribe(function (data) {
            console.log(JSON.stringify(data));
            if (data.messageResponseObj.code == "000") {
                //Succed
                _this.services = data.serviceDtos;
            }
            else {
                //Fail
                alert("fail");
            }
        });
    };
    ServiceComponent.prototype.addAttributeValue = function () {
        this.attributeValueEdit.push(new IAttributeValue_1.IAttributeValue());
    };
    ServiceComponent.prototype.addAttributeToService = function () {
        this.attributeEdit.attributeValueListCollection = this.attributeValueEdit;
        this.attributeEdit.type = this.attributeValueEdit.length > 1 ? "List" : "Single";
        this.attributeValueEdit = new Array();
        this.serviceAttributes.push(this.attributeEdit);
        this.attributeEdit = new IAttribute_1.IAttribute();
    };
    ServiceComponent.prototype.removeAttribute = function (event) {
        //event.target.id
        this.attributeValueEdit.splice(event.target.id, 1);
    };
    ServiceComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.getServices();
        this.getCatgories();
        //get all components
        this.componentService.getAllComponents().subscribe(function (data) {
            if (data.messageResponseObj.code == "000") {
                //Succed
                _this.components = data.components;
            }
            else {
                //Fail
                alert("fail");
            }
        });
    };
    ServiceComponent.prototype.addService = function () {
        //Prepare Service
        this.toBeSaved.attributeCollection = this.serviceAttributes;
        this.toBeSaved.componentCollection = this.serviceComponetList;
        //call add services
        //console.log(JSON.stringify(this.toBeSaved));
        this.serviceService.addService(this.toBeSaved).subscribe();
        this.serviceComponetList = new Array();
        this.serviceAttributes = new Array();
        this.toBeSaved = new IService_1.IService();
    };
    //get Catgoreies
    ServiceComponent.prototype.getCatgories = function () {
        var _this = this;
        this.catgoreyService.getAllCategoriesNames().subscribe(function (data) {
            if (data.messageResponseObj.code == "000") {
                //success
                _this.catgories = data.categories;
                console.log(_this.catgories);
            }
            else {
            }
            console.log(data);
        });
    };
    ServiceComponent.prototype.setCatgories = function () {
    };
    //onchange select of catgorey
    ServiceComponent.prototype.onChange = function (id) {
        console.log("HERE");
        this.candidatecomp = this.components.filter(function (item) { return item.categoryId != null && item.categoryId.id == id; });
        this.candycomp = this.candidatecomp[0];
    };
    //on change select component
    ServiceComponent.prototype.onChangeSelectComponent = function (compnet) {
        console.log(IComponent_1.IComponent);
        this.candycomp = this.components.filter(function (item) { return item.id == compnet; })[0];
    };
    //addComponent To service
    ServiceComponent.prototype.addComponentToService = function () {
        this.serviceComponetList.push(this.candycomp);
        this.candycomp = new IComponent_1.IComponent();
    };
    //remove componet from service
    ServiceComponent.prototype.removeFromService = function (e) {
        this.serviceComponetList = this.serviceComponetList.filter(function (item) { return item.id != e.target.id; });
    };
    //remove attr from service
    ServiceComponent.prototype.removeAttrFromService = function (event) {
        this.serviceAttributes.splice(event.target.id, 1);
    };
    return ServiceComponent;
}());
ServiceComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'ServiceAll',
        templateUrl: './service.html',
    }),
    __metadata("design:paramtypes", [service_service_1.ServiceService, component_service_1.ComponentService, category_service_1.CategoryService, core_1.ChangeDetectorRef, router_1.Router])
], ServiceComponent);
exports.ServiceComponent = ServiceComponent;
//# sourceMappingURL=service.component.js.map