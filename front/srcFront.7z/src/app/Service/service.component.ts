import { Component, OnInit, ChangeDetectorRef, Input, ViewChild, ElementRef } from '@angular/core';
import { NgForm, FormBuilder, Validators } from "@angular/forms";
import { Router } from '@angular/router'
import { ServiceService } from './service.service';
import { IService } from '../Infrastructure/IService';
import { ICategory } from '../Infrastructure/ICatgorey';
import { IComponent } from '../Infrastructure/IComponent';
import { IAttributeValue } from '../Infrastructure/IAttributeValue';
import { IAttribute } from '../Infrastructure/IAttribute';

import { CategoryService } from '../category/category.service';
import { ComponentService } from '../Component/component.service';



@Component({
    moduleId: module.id,
    selector: 'ServiceAll',
    templateUrl: './service.html',
})
export class ServiceComponent implements OnInit {
    toBeSaved = new IService();
    candidatecomp: IComponent[];
    candycomp = new IComponent();
    serviceComponetList = new Array<IComponent>();
    attributeEdit = new IAttribute();
    attributeValueEdit = new Array<IAttributeValue>();
    serviceAttributes = new Array<IAttribute>();
    serviceAttributeValues = new Array<IAttributeValue>();
    services = new Array<IService>();
    getServices() {
        this.serviceService.getAllServices().subscribe(data => {
            console.log(JSON.stringify(data));
              if (data.messageResponseObj.code == "000") {
                    //Succed
                    this.services = data.serviceDtos;
                } else {
                    //Fail
                    alert("fail");
                }

        });
    }
    addAttributeValue() {
        this.attributeValueEdit.push(new IAttributeValue());

    }

    addAttributeToService() {
        this.attributeEdit.attributeValueListCollection = this.attributeValueEdit;
        this.attributeEdit.type = this.attributeValueEdit.length > 1 ? "List" : "Single";
        this.attributeValueEdit = new Array<IAttributeValue>();
        this.serviceAttributes.push(this.attributeEdit);
        this.attributeEdit = new IAttribute();

    }

    removeAttribute(event: any) {
        //event.target.id
        this.attributeValueEdit.splice(event.target.id, 1);
    }

    ngOnInit(): void {
        this.getServices();
        this.getCatgories();
        //get all components
        this.componentService.getAllComponents().subscribe(
            (data: any) => {

                if (data.messageResponseObj.code == "000") {
                    //Succed
                    this.components = data.components;
                } else {
                    //Fail
                    alert("fail");
                }
            });

    }

    addService() {
        //Prepare Service
        this.toBeSaved.attributeCollection = this.serviceAttributes;
        this.toBeSaved.componentCollection = this.serviceComponetList;
        //call add services
        //console.log(JSON.stringify(this.toBeSaved));
        this.serviceService.addService(this.toBeSaved).subscribe();
        this.serviceComponetList = new Array<IComponent>();
        this.serviceAttributes = new Array<IAttribute>();
        this.toBeSaved = new IService();
    }
    components: IComponent[];
    catgories: ICategory[];
    //get Catgoreies
    getCatgories() {
        this.catgoreyService.getAllCategoriesNames().subscribe(data => {
            if (data.messageResponseObj.code == "000") {
                //success
                this.catgories = data.categories;
                console.log(this.catgories);
            }
            else {
                //fail

            }
            console.log(data);

        });
    }
    setCatgories() {

    }
    //onchange select of catgorey
    onChange(id: any) {
        console.log("HERE");
        this.candidatecomp = this.components.filter(item => item.categoryId != null && item.categoryId.id == id);
        this.candycomp = this.candidatecomp[0];
    }
    //on change select component
    onChangeSelectComponent(compnet: any) {
        console.log(IComponent);
        this.candycomp = this.components.filter(item => item.id == compnet)[0];

    }

    //addComponent To service
    addComponentToService() {
        this.serviceComponetList.push(this.candycomp);
        this.candycomp = new IComponent();
    }

    //remove componet from service
    removeFromService(e: any) {
        this.serviceComponetList = this.serviceComponetList.filter(item => item.id != e.target.id);
    }

    //remove attr from service
    removeAttrFromService(event: any) {
        this.serviceAttributes.splice(event.target.id, 1);
    }

    constructor(private serviceService: ServiceService, private componentService: ComponentService, private catgoreyService: CategoryService, private changeDetectorRef: ChangeDetectorRef, private router: Router) {

    }
}