"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var app_component_1 = require("./app.component");
var http_1 = require("@angular/http");
var category_service_1 = require("./category/category.service");
var category_component_1 = require("./category/category.component");
var addCategory_compoenet_1 = require("./category/addCategory.compoenet");
var app_nav_1 = require("./navigation/app.nav");
var editCategory_component_1 = require("./category/editCategory.component");
var order_service_1 = require("./Order/order.service");
var addOrder_component_1 = require("./Order/addOrder.component");
var viewOrder_component_1 = require("./Order/viewOrder.component");
var key_pipe_1 = require("./Order/key.pipe");
var component_service_1 = require("./Component/component.service");
var component_component_1 = require("./Component/component.component");
var service_component_1 = require("./Service/service.component");
var home_component_1 = require("./home/home.component");
var home_service_1 = require("./home/home.service");
var service_service_1 = require("./Service/service.service");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        providers: [category_service_1.CategoryService, order_service_1.OrderService, component_service_1.ComponentService, home_service_1.HomeService, service_service_1.ServiceService],
        imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, http_1.HttpModule, app_nav_1.AppRoutingModule],
        declarations: [app_component_1.AppComponent, category_component_1.CategoryComponent, addCategory_compoenet_1.AddCategory, editCategory_component_1.EditCategoryComponent,
            addOrder_component_1.AddOrderComponent, viewOrder_component_1.ViewOrder, key_pipe_1.KeysPipe, component_component_1.ComponentComponent, home_component_1.HomeComponent, service_component_1.ServiceComponent],
        bootstrap: [app_component_1.AppComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map