"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var component_service_1 = require("./component.service");
var IComponent_1 = require("../Infrastructure/IComponent");
var category_service_1 = require("../category/category.service");
var ComponentComponent = (function () {
    function ComponentComponent(componentService, catgoreyService, changeDetectorRef, router) {
        this.componentService = componentService;
        this.catgoreyService = catgoreyService;
        this.changeDetectorRef = changeDetectorRef;
        this.router = router;
        this.components = new Array();
        this.wholecomp = new Array();
        this.viewcomponents = [];
        this.toBeSaved = new IComponent_1.IComponent();
        this.pagination = [];
        this.pagnum = 0;
    }
    //get Catgoreies
    ComponentComponent.prototype.getCatgories = function () {
        var _this = this;
        this.catgoreyService.getAllCategoriesNames().subscribe(function (data) {
            if (data.messageResponseObj.code == "000") {
                //success
                _this.catgories = data.categories;
                console.log(_this.catgories);
            }
            else {
            }
            console.log(data);
        });
    };
    ComponentComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.router.params.subscribe(function (params) {
            if (params['id'] != null)
                _this.catIDfromCatgorey = +params['id'];
        });
        this.componentService.getAllComponents().subscribe(function (data) {
            if (data.messageResponseObj.code == "000") {
                //Succed
                _this.wholecomp = data.components;
                _this.components = _this.wholecomp.filter(function (item) { return item.categoryId != null && item.categoryId.id == _this.catIDfromCatgorey; });
                console.log(_this.wholecomp);
            }
            else {
                //Fail
                alert("fail");
            }
        });
        this.getCatgories();
        for (var i = 1; i <= this.components.length / 10; i++)
            this.pagination.push(i);
    };
    //Close Modals
    ComponentComponent.prototype.closeModal = function () {
        console.log(this.closeBtn);
        //Close ADD modal
        this.closeBtn.nativeElement.click();
        //Close Edit Modal
        this.closeBtn2.nativeElement.click();
        //Close Delete Modal
        this.closeBtn3.nativeElement.click();
    };
    //Delete Component Method 
    //Argument >>e EVEnt
    ComponentComponent.prototype.deleteComponent = function () {
        var _this = this;
        //Call Delete Service with the ID of target Object
        this.componentService.deleteComponent(this.toBeDeleted).subscribe(function (data) {
            //Check response
            if (data.messageResponseObj.code == "000") {
                //Succed
                //Remove Deleted Object From View
                _this.components = _this.components.filter(function (item) { return item.id != _this.toBeDeleted; });
                _this.closeModal();
            }
            else {
                //Fail
                alert("fail");
            }
        });
    };
    //get the id of target object before open modal 
    ComponentComponent.prototype.setDeletedID = function (e) {
        this.toBeDeleted = e.target.id;
    };
    //on cahnge select catgorey
    ComponentComponent.prototype.onChange = function (e) {
        console.log(e.target.value);
        this.toBeSaved.categoryId = this.catgories.filter(function (item) { return item.id == e.target.value; })[0];
    };
    //add Component
    ComponentComponent.prototype.addComponent = function () {
        var _this = this;
        //call add services        
        console.log(JSON.stringify(this.toBeSaved));
        this.componentService.addComponent(this.toBeSaved).subscribe(function (data) {
            console.log(data);
            if (data.messageResponseObj.code == "000") {
                //Succed
                //add object to view
                _this.toBeSaved.id = data.componentID;
                _this.components.push(_this.toBeSaved);
                //reintialize the temp oject
                _this.toBeSaved = new IComponent_1.IComponent();
                _this.closeModal();
            }
            else {
                //Fail
                alert("fail");
            }
        });
    };
    //edit Component
    //get target object before open modal
    ComponentComponent.prototype.prepareEdit = function (event) {
        var _this = this;
        //get target id
        this.toBeDeleted = event.target.id;
        //get the target object
        this.toBeSaved = this.components.filter(function (item) { return item.id == _this.toBeDeleted; })[0];
    };
    //edit method
    ComponentComponent.prototype.editComponent = function () {
        var _this = this;
        //call the edit service
        this.toBeSaved.id = this.toBeDeleted;
        this.componentService.updateComponent(this.toBeSaved).subscribe(function (data) {
            //check result
            if (data.messageResponseObj.code == "000") {
                //Succed
                //put the edited object to view
                _this.components.forEach(function (element) {
                    if (element.id == _this.toBeSaved.id) {
                        element = _this.toBeSaved;
                    }
                });
                //reintialize temp object
                _this.toBeSaved = new IComponent_1.IComponent();
                _this.closeModal();
            }
            else {
                //Fail
                alert("fail");
            }
        });
    };
    return ComponentComponent;
}());
__decorate([
    core_1.ViewChild('closeBtn'),
    __metadata("design:type", core_1.ElementRef)
], ComponentComponent.prototype, "closeBtn", void 0);
__decorate([
    core_1.ViewChild('closeBtn2'),
    __metadata("design:type", core_1.ElementRef)
], ComponentComponent.prototype, "closeBtn2", void 0);
__decorate([
    core_1.ViewChild('closeBtn3'),
    __metadata("design:type", core_1.ElementRef)
], ComponentComponent.prototype, "closeBtn3", void 0);
ComponentComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'ComponentAll',
        templateUrl: './component.html',
        styleUrls: ['./Tabble.css']
    }),
    __metadata("design:paramtypes", [component_service_1.ComponentService, category_service_1.CategoryService, core_1.ChangeDetectorRef, router_1.ActivatedRoute])
], ComponentComponent);
exports.ComponentComponent = ComponentComponent;
//# sourceMappingURL=component.component.js.map