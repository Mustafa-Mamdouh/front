export class AttributeValueList {
    value: string;

}