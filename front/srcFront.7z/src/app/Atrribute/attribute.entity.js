"use strict";
var Attribute = (function () {
    function Attribute() {
        this.attributeValue = new Array();
        //service:Service;
    }
    return Attribute;
}());
exports.Attribute = Attribute;
//# sourceMappingURL=attribute.entity.js.map