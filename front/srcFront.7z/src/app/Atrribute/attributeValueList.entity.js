"use strict";
var AttributeValueList = (function () {
    function AttributeValueList() {
    }
    return AttributeValueList;
}());
exports.AttributeValueList = AttributeValueList;
//# sourceMappingURL=attributeValueList.entity.js.map