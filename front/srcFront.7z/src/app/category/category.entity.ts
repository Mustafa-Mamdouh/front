export class Category {
    id: number;
    name: string;
    type: string;

}