"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var category_service_1 = require("./category.service");
var category_entity_1 = require("./category.entity");
var CategoryComponent = (function () {
    function CategoryComponent(categoryService, changeDetectorRef, router) {
        this.categoryService = categoryService;
        this.changeDetectorRef = changeDetectorRef;
        this.router = router;
        this.categories = [];
        this.editCategory = new category_entity_1.Category();
        this.deleteCategory = new category_entity_1.Category();
        this.newCategory = new category_entity_1.Category();
    }
    CategoryComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.categoryService.getAllCategories().subscribe(function (data) {
            var myArray = [];
            for (var key in data) {
                myArray.push(data[key]);
            }
            _this.categories = data;
        });
    };
    CategoryComponent.prototype.deleteService = function () {
        this.categoryService.deleteCategory(this.categories[this.rowNumber].id).subscribe();
        this.categories.splice(this.rowNumber, 1);
        this.changeDetectorRef.detectChanges();
    };
    CategoryComponent.prototype.edit = function (categoryRow) {
        this.rowNumber = categoryRow;
        this.editCategory.id = this.categories[categoryRow].id;
        this.editCategory.name = this.categories[categoryRow].name;
        this.editCategory.type = this.categories[categoryRow].type;
    };
    CategoryComponent.prototype.deleteCategoryRow = function (rowIndex) {
        this.rowNumber = rowIndex;
        this.deleteCategory.name = this.categories[rowIndex].name;
    };
    CategoryComponent.prototype.updateCategory = function () {
        this.categoryService.updateCategory(this.editCategory).subscribe();
        this.categories[this.rowNumber].name = this.editCategory.name;
        this.categories[this.rowNumber].type = this.editCategory.type;
    };
    CategoryComponent.prototype.addCategory = function () {
        var _this = this;
        this.categoryService.addCategory(this.newCategory).subscribe(function (data) {
            _this.categories.push(data);
        });
        this.newCategory.name = "";
        this.newCategory.type = "";
    };
    CategoryComponent.prototype.view = function (categoryRow) {
        this.router.navigate(['component', this.categories[categoryRow].id]);
    };
    return CategoryComponent;
}());
CategoryComponent = __decorate([
    core_1.Component({
        selector: 'pm-app',
        templateUrl: './category.component.html'
    }),
    __metadata("design:paramtypes", [category_service_1.CategoryService, core_1.ChangeDetectorRef, router_1.Router])
], CategoryComponent);
exports.CategoryComponent = CategoryComponent;
//# sourceMappingURL=category.component.js.map